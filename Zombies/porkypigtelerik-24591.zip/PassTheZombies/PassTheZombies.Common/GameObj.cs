﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassTheZombies.Common
{
    public abstract class GameObj : IKillable, IRenderable
    {
        public const string CollisionGroupString = "object";
        protected MatrixCoords position;
        protected char body;

        protected GameObj(MatrixCoords position, char body)
        {
            this.position = position;
            this.body = body;

            this.IsDestroyed = false;
        }

        public bool IsDestroyed { get; protected set; }
        public MatrixCoords Position
        {
            get
            {
                return this.position;
            }
            set
            {
                this.position = value;
            }
        }

        public bool CanCollideWith(string collisionGroupString)
        {
            return GameObj.CollisionGroupString == collisionGroupString;
        }

        public string GetCollisionGroupString()
        {
            return GameObj.CollisionGroupString;
        }

        public virtual void Die()
        {
            IsDestroyed = true;
        }

        public void RespondToCollision() { }
        
        public abstract void Update();
        
        public MatrixCoords GetPosition()
        {
            return this.Position;
        }

        public virtual char GetImage()
        {
            return this.body;
        }

        public MatrixCoords GetTopLeft()
        {
            return this.position;
        }

        char IRenderable.GetImage()
        {
            return this.body;
        }
    }
}
