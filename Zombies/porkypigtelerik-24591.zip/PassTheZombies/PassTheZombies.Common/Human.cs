﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassTheZombies.Common
{
    public class Human : GameObj, ICollidable, IMovable, IHealable
    {
        private int health = 100;
        public const string CollisionGroupString = "human";

        public Human(MatrixCoords position, char body, int health)
            : base(position, body)
        {
            Health = health;
        }

        public int Health
        {
            get { return this.health; }
            private set { this.health = value; }
        }

        public void Heal(int amount)
        {
            this.health += amount;
            if (this.health > 100)
            {
                this.health = 100;
            }
        }

        public override void Update() { }

        public void MoveLeft()
        {
            throw new NotImplementedException();
        }

        public void MoveRight()
        {
            throw new NotImplementedException();
        }

        public void MoveUp()
        {
            throw new NotImplementedException();
        }

        public void MoveDown()
        {
            throw new NotImplementedException();
        }
    }
}
