﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassTheZombies.Common
{
    public class Item : GameObj, ITakeable
    {
        public const string CollisionGroupString = "item";

        public Item(MatrixCoords topLeft, char body)
            : base(topLeft, body)
        {
        }

        public virtual void Take() { }
        public override void Update() { }

    }
}
