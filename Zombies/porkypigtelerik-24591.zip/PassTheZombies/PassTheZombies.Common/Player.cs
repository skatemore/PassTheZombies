﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassTheZombies.Common
{
    // SINGLETON PLAYER CLASS
    public class Player : Human
    {
        static MatrixCoords DEFAULT_PLAYER_POSITION = new MatrixCoords(40 - 2, 2);
        private static Player player;
        public const string CollisionGroupString = "player";
        public static char playerBody = 'o';

        private Player(MatrixCoords position, int health)
            : base(position, playerBody, health)
        { }

        public static Player Instance
        {
            get
            {
                if (player == null)
                {
                    player = new Player(DEFAULT_PLAYER_POSITION, 100);
                }
                return player;
            }
        }
        
        public override void Update() { }

    }
}
