﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PassTheZombies.Common;

namespace PassTheZombies.UI
{
    class PassTheZombiesUI
    {
        static void Main(string[] args)
        {
            ConsoleRenderer gameRenderer = new ConsoleRenderer(40,130);
            Console.WindowWidth = Console.BufferWidth = 130;
            Console.WindowHeight = Console.BufferHeight = 40;

            Player player = Player.Instance;
            gameRenderer.EnqueueForRendering(player);
            gameRenderer.RenderAll();
        }
    }
}
